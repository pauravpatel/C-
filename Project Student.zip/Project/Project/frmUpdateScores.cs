﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class frmUpdateScores : Form
    {
        public static Dictionary<string, List<int>> tmpStudents;
        BindingSource bs = new BindingSource();
        public static int selected;
        
        public frmUpdateScores()
        {
            InitializeComponent();
        }

      
        private void UpdateScores_Load(object sender, EventArgs e)
        {
            tmpStudents = frmStudentScores.students.ToDictionary(p => p.Key, p => p.Value.ToList());
         txtName.Text = tmpStudents.Keys.ElementAt(frmStudentScores.selected);
            bs.DataSource = tmpStudents.Values.ElementAt(frmStudentScores.selected);
            listBoxScores.DataSource = bs;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form addScore = new frmAdd_Score();
            addScore.ShowDialog();
            bs.ResetBindings(false);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Form updateScore = new frmUpdate();
            selected = listBoxScores.SelectedIndex;
            
            updateScore.ShowDialog();
            bs.ResetBindings(false);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            tmpStudents.Values.ElementAt(frmStudentScores.selected).RemoveAt(listBoxScores .SelectedIndex);
            bs.ResetBindings(false);
        }

        private void btnClearScores_Click(object sender, EventArgs e)
        {
            tmpStudents.Values.ElementAt(frmStudentScores.selected).RemoveRange(
                0, tmpStudents.Values.ElementAt(frmStudentScores.selected).Count);
            bs.ResetBindings(false);
        }

        private void listBoxScores_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            frmStudentScores.students = tmpStudents;
            this.Close();
        }
    }
}
