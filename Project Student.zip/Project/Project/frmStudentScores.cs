﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class frmStudentScores : Form
    {
        public static Dictionary<string, List<int>> students = new Dictionary<string, List<int>>();
        public static int selected;
        

        public frmStudentScores()
        {
            InitializeComponent();
        }


        private void AddToListbox()
        {
            foreach (var student in students)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(student.Key.ToString());
                sb.Append(" - ");
                for (int i = 0; i < student.Value.Count; i++)
                {
                    sb.Append(student.Value[i]);
                    if (i != student.Value.Count - 1)
                    {
                        sb.Append(", ");
                    }
                }
                listBox1.Items.Add(sb);
                listBox1.SetSelected(0, true);
                UpdateNewInfo();
            }
        }


        private void UpdateNewInfo()
        {
            try
            {

                txtScoreTotal.Text = students.Values.ElementAt(listBox1.SelectedIndex).Sum().ToString();
                txtScoreCount.Text = students.Values.ElementAt(listBox1.SelectedIndex).Count.ToString();
                txtAverage.Text = Math.Round(students.Values.ElementAt(listBox1.SelectedIndex).Average()).ToString();
            }
            catch (Exception)
            {
                txtScoreTotal.Text = "";
                txtScoreCount.Text = "";
                txtAverage.Text = "";
            }
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form AddNew = new frmAddScore();
            AddNew.ShowDialog();
            listBox1.Items.Clear();
            AddToListbox();


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateNewInfo();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Form Update = new frmUpdateScores();
          
            selected = listBox1.SelectedIndex;
            if (listBox1.Items.Count > 0)
            {
                Update.ShowDialog();
            }
            listBox1.Items.Clear();
            AddToListbox();

        }

        private void frmStudentScores_Activated(object sender, EventArgs e)
        {
            UpdateNewInfo();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        //private void frmStudentScores_Load(object sender, EventArgs e)
        //{
            
        ////    students.Add("Peter Cornell", new List<int> { 20, 30, 50 });
        // //   students.Add("Joe Whatsits", new List<int> { 24, 44, 34 });
        //   students.Add("Jane Harris", new List<int> { 64, 43, 65 });
            
        //    AddToListbox();

        //    // TODO select first in listbox on load
        //}

        private void btnDelete_Click(object sender, EventArgs e)
        {
            students.Remove(students.Keys.ElementAt( listBox1.SelectedIndex));
            listBox1.Items.Clear();
            AddToListbox();
            if (students.Count == 0)
            {
                txtScoreTotal.Text = "";
                txtScoreCount.Text = "";
                txtAverage.Text = "";
            }
        }

        private void frmStudentScores_Load(object sender, EventArgs e)
        {
            students.Add("Peter Cornell", new List<int> { 20, 30, 50 });
            students.Add("Joe Whatsits", new List<int> { 24, 44, 34 });
            students.Add("Jane Harris", new List<int> { 64, 43, 65 });

            AddToListbox();
        }
    }
}
