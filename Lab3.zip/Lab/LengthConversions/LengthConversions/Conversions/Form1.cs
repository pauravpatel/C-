using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Conversions
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private decimal conversion;

        string[,] conversionTable = {
            {"Miles to kilometers", "Miles", "Kilometers", "1.6093"},
            {"Kilometers to miles", "Kilometers", "Miles", "0.6214"},
            {"Feet to meters", "Feet", "Meters", "0.3048"},
            {"Meters to feet", "Meters", "Feet", "3.2808"},
            {"Inches to centimeters", "Inches", "Centimeters", "2.54"},
            {"Centimeters to inches", "Centimeters", "Inches", "0.3937"}
        };

        public bool IsPresent(TextBox textBox, string name)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(name + " is a required field.", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }

        public bool IsDecimal(TextBox textBox, string name)
        {
            try
            {
                Convert.ToDecimal(textBox.Text);
                return true;
            }
            catch (FormatException)
            {
                MessageBox.Show(name + "must be a decimal number.", "Entry Error");
                textBox.Focus();
                return false;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
            cboConversions.SelectedIndex = 0;
            txtLength.Text = "1";
            lblCalculatedLength.Text = conversionTable[0, 3]; 
            txtLength.Focus();
           
        }

        private void cboConversions_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cboConversions.SelectedIndex == 0)
            {
              
                txtLength.Text = "1";
                lblCalculatedLength.Text = conversionTable[0, 3];
                txtLength.Focus();
                
            }
            if (cboConversions.SelectedIndex == 1)
            {
              
                txtLength.Text = "1";
               lblCalculatedLength.Text = conversionTable[1, 3];
                txtLength.Focus();
            }
            if (cboConversions.SelectedIndex == 2)
            {
              
                txtLength.Text = "1";
                lblCalculatedLength.Text = conversionTable[2, 3];
                txtLength.Focus();
            }
            if (cboConversions.SelectedIndex == 3)
            {
              
                txtLength.Text = "1";
                lblCalculatedLength.Text = conversionTable[3, 3];
                txtLength.Focus();
            }
            if (cboConversions.SelectedIndex == 4)
            {
              
                txtLength.Text = "1";
                lblCalculatedLength.Text = conversionTable[4, 3];
                txtLength.Focus();
            }
            if (cboConversions.SelectedIndex == 5)
            {
              
                txtLength.Text = "1";
                lblCalculatedLength.Text = conversionTable[5, 3];
                txtLength.Focus();
            }
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal d;
            if (decimal.TryParse(txtLength.Text, out d))
            {
                decimal length = Convert.ToDecimal(txtLength.Text);
                if (cboConversions.SelectedIndex == 0)
                {
                    conversion = Convert.ToDecimal(conversionTable[0, 3]) * length;
                    lblCalculatedLength.Text = conversion.ToString();
                }
                if (cboConversions.SelectedIndex == 1)
                {
                    conversion = Convert.ToDecimal(conversionTable[1, 3]) * length;
                    lblCalculatedLength.Text = conversion.ToString();
                }
                if (cboConversions.SelectedIndex == 2)
                {
                    conversion = Convert.ToDecimal(conversionTable[2, 3]) * length;
                    lblCalculatedLength.Text = conversion.ToString();
                }
                if (cboConversions.SelectedIndex == 3)
                {
                    conversion = Convert.ToDecimal(conversionTable[3, 3]) * length;
                    lblCalculatedLength.Text = conversion.ToString();
                }
                if (cboConversions.SelectedIndex == 4)
                {
                    conversion = Convert.ToDecimal(conversionTable[4, 3]) * length;
                    lblCalculatedLength.Text = conversion.ToString();
                }
                if (cboConversions.SelectedIndex == 5)
                {
                    conversion = Convert.ToDecimal(conversionTable[5, 3]) * length;
                    lblCalculatedLength.Text = conversion.ToString();
                }
            }
            else
                MessageBox.Show("Please enter a valid decimal number.", "Error");
        }
    }
}