using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LunchOrder
{

    public partial class Form1 : Form
    {
        double tax;
        double subTotal;
        double total;
        double addonPrice;
        double HamAddonPrice = .75;
        double PizzaAddonPrice = .50;
        double HamburgerPrice = 6.95;
        double SaladAddonPrice = .25;
        double PizzaPrice = 5.95;
        double SaladPrice = 4.95;
        double TaxRate = .0775;


        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rdoHamburger.Checked = true;
        }

        private void rdoHamburger_CheckedChanged(object sender, EventArgs e)
        {

            ClearAddOns();
            ClearTotals();
            if (rdoHamburger.Checked == true)

            {
                gbxAddOn.Text = "Add-on items ($.75/each)";
                checkBox1.Text = "Lettuce, tomato, and onions";
                checkBox2.Text = "Ketchup, mustard, and mayo";
                checkBox3.Text = "French Fries";
                
            }
        }

        private void rdoPizza_CheckedChanged(object sender, EventArgs e)
        {
            ClearAddOns();
            ClearTotals();

            if (rdoPizza.Checked == true)

            gbxAddOn.Text = "Add-on items ($.50/each)";
            checkBox1.Text = "Pepperoni";
            checkBox2.Text = "Sausage";
            checkBox3.Text = "olives";
        }

        private void rdoSalad_CheckedChanged(object sender, EventArgs e)
        {

            ClearAddOns();
            ClearTotals(); 


            if (rdoSalad.Checked == true)

            gbxAddOn.Text = "Add-on items ($.25/each)";
            checkBox1.Text = "Croutons ";
            checkBox2.Text = "Bacon bit";
            checkBox3.Text = "Bread sticks";
        }

        private void ClearAddOns()
        {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
        }

        private void ClearTotals()
        {
            lblOrderTotal.Text = string.Empty;
            lblSubtotal.Text = string.Empty;
            lblSalesTax.Text = string.Empty;
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {

            if (rdoHamburger.Checked)
            {
                addonPrice = HamAddonPrice;
                subTotal = HamburgerPrice;
               
            }
            else if (rdoPizza.Checked)
            {
                addonPrice = PizzaAddonPrice;
                subTotal = PizzaPrice;
                
            }
            else
            {
                addonPrice = SaladAddonPrice;
                subTotal = SaladPrice;
            }
            if (checkBox1.Checked)
                subTotal += addonPrice;
            if (checkBox2.Checked)
                subTotal += addonPrice;
            if (checkBox3.Checked)
                subTotal += addonPrice;
            tax = subTotal * TaxRate;
            total = subTotal + tax;
            lblSubtotal.Text = Convert.ToString(subTotal);

            lblSalesTax.Text = Convert.ToString(tax);

            lblOrderTotal.Text = Convert.ToString(total);

            
        }


    }
}
