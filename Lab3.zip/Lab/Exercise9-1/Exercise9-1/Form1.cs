﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise9_1
{

    public partial class Form1 : Form
    {
        DateTime Adate;
        DateTime Ddate;
        double avgprice;
        double pricepernight = 140;

        double totalprice;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {

            try
            {

                if (IsValidData())
                {
                    Adate = Convert.ToDateTime(txtArrDate.Text);
                    Ddate = Convert.ToDateTime(txtDedate.Text);
                  
                    TimeSpan night = Ddate.Subtract(Adate);
                    txtNights.Text = Convert.ToString(night.Days);


                    for (DateTime date = Adate; date <= Ddate; date = date.AddDays(1))
                    {
                        DayOfWeek dayOfWeek = date.DayOfWeek;

                        if (dayOfWeek == DayOfWeek.Friday || dayOfWeek == DayOfWeek.Saturday)
                        {
                            pricepernight += 30;
                            avgprice = pricepernight * night.Days;

                        }
                        else
                        {
                            avgprice = pricepernight * night.Days;

                        }

                        totalprice = pricepernight * Convert.ToInt32(night.Days);
                        txtPrice.Text = Convert.ToString(totalprice);

                        avgprice = totalprice / Convert.ToDouble(night.Days);
                        txtAvgprice.Text = Convert.ToString(avgprice);
                    }

                }
            }
            catch (Exception ex)            {                MessageBox.Show("Incorrect Date Formate");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DateTime currentdate = DateTime.Now;
            String Aformate = String.Format("{0:M/d/yy}", currentdate);
            txtArrDate.Text = Convert.ToString(Aformate);


            DateTime arrive = currentdate;
            DateTime depart = arrive.AddDays(3);
            String Dformate = String.Format("{0:M/d/yy}", depart);
            txtDedate.Text = Convert.ToString(Dformate);

        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public bool IsPresent(TextBox textBox, string name)        {            if (textBox.Text == "")            {                MessageBox.Show(name + " is a required field.", "Entry Error");                textBox.Focus();                return false;            }            return true;        }

        public bool IsDateTime(TextBox textBox, string name)
        {
            DateTime dateTime=DateTime.Now;

            if (DateTime.TryParse(textBox.Text, out dateTime)==false)
            {
                MessageBox.Show("Must be valid");
                return false;
            }
            return true;
          
        }

        public bool IsWithinRange(TextBox textBox, string name, DateTime min, DateTime max)
        {

            DateTime enteredDate = DateTime.Parse(textBox.Text);
            if (enteredDate < min || enteredDate > max)
            {
                MessageBox.Show(name+"Out Of Range"+min+"and"+max);
                textBox.Focus();
                return false;
            }
            return true;

        }

        public bool IsValidData()

        {
            return

                IsPresent(txtArrDate, "Adate") &&
                IsDateTime(txtArrDate, "Adate") &&
                IsWithinRange(txtArrDate, "Adate", DateTime.Today, DateTime.Today.AddYears(5)) &&


            IsPresent(txtDedate, "Ddate") &&
              IsDateTime(txtDedate, "Ddate") &&
              IsWithinRange(txtDedate, "Adate", DateTime.Today, DateTime.Today.AddYears(5));
        }
    }
}