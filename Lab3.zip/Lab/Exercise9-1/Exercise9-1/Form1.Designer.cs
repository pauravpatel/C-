﻿namespace Exercise9_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAdate = new System.Windows.Forms.Label();
            this.lblDdate = new System.Windows.Forms.Label();
            this.lblNights = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblAvg = new System.Windows.Forms.Label();
            this.txtArrDate = new System.Windows.Forms.TextBox();
            this.txtDedate = new System.Windows.Forms.TextBox();
            this.txtNights = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtAvgprice = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAdate
            // 
            this.lblAdate.AutoSize = true;
            this.lblAdate.Location = new System.Drawing.Point(13, 33);
            this.lblAdate.Name = "lblAdate";
            this.lblAdate.Size = new System.Drawing.Size(63, 13);
            this.lblAdate.TabIndex = 0;
            this.lblAdate.Text = "Arrival date:\r\n";
            // 
            // lblDdate
            // 
            this.lblDdate.AutoSize = true;
            this.lblDdate.Location = new System.Drawing.Point(13, 75);
            this.lblDdate.Name = "lblDdate";
            this.lblDdate.Size = new System.Drawing.Size(77, 13);
            this.lblDdate.TabIndex = 1;
            this.lblDdate.Text = "Depature Date";
            // 
            // lblNights
            // 
            this.lblNights.AutoSize = true;
            this.lblNights.Location = new System.Drawing.Point(13, 114);
            this.lblNights.Name = "lblNights";
            this.lblNights.Size = new System.Drawing.Size(87, 13);
            this.lblNights.TabIndex = 2;
            this.lblNights.Text = "Number of nights";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(13, 155);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(58, 13);
            this.lblPrice.TabIndex = 3;
            this.lblPrice.Text = "Total Price";
            // 
            // lblAvg
            // 
            this.lblAvg.AutoSize = true;
            this.lblAvg.Location = new System.Drawing.Point(13, 189);
            this.lblAvg.Name = "lblAvg";
            this.lblAvg.Size = new System.Drawing.Size(99, 13);
            this.lblAvg.TabIndex = 4;
            this.lblAvg.Text = "Avg price per night:\r\n";
            // 
            // txtArrDate
            // 
            this.txtArrDate.Location = new System.Drawing.Point(132, 26);
            this.txtArrDate.Name = "txtArrDate";
            this.txtArrDate.Size = new System.Drawing.Size(100, 20);
            this.txtArrDate.TabIndex = 5;
            // 
            // txtDedate
            // 
            this.txtDedate.Location = new System.Drawing.Point(132, 68);
            this.txtDedate.Name = "txtDedate";
            this.txtDedate.Size = new System.Drawing.Size(100, 20);
            this.txtDedate.TabIndex = 6;
            // 
            // txtNights
            // 
            this.txtNights.Location = new System.Drawing.Point(132, 111);
            this.txtNights.Name = "txtNights";
            this.txtNights.ReadOnly = true;
            this.txtNights.Size = new System.Drawing.Size(100, 20);
            this.txtNights.TabIndex = 7;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(132, 148);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.ReadOnly = true;
            this.txtPrice.Size = new System.Drawing.Size(100, 20);
            this.txtPrice.TabIndex = 8;
            // 
            // txtAvgprice
            // 
            this.txtAvgprice.Location = new System.Drawing.Point(132, 186);
            this.txtAvgprice.Name = "txtAvgprice";
            this.txtAvgprice.ReadOnly = true;
            this.txtAvgprice.Size = new System.Drawing.Size(100, 20);
            this.txtAvgprice.TabIndex = 9;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(12, 226);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 10;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(117, 226);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtAvgprice);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtNights);
            this.Controls.Add(this.txtDedate);
            this.Controls.Add(this.txtArrDate);
            this.Controls.Add(this.lblAvg);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblNights);
            this.Controls.Add(this.lblDdate);
            this.Controls.Add(this.lblAdate);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAdate;
        private System.Windows.Forms.Label lblDdate;
        private System.Windows.Forms.Label lblNights;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblAvg;
        private System.Windows.Forms.TextBox txtArrDate;
        private System.Windows.Forms.TextBox txtDedate;
        private System.Windows.Forms.TextBox txtNights;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtAvgprice;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnExit;
    }
}

