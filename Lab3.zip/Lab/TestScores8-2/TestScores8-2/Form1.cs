﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestScores8_2
{
    public partial class Form1 : Form
    {

        int total;
        int average;
        int count; 
        List<int> scoreList = new List<int>();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
           

            int score = int.Parse(txtScore.Text);

            scoreList.Add(score);

            total += score;
            txtTotal.Text = Convert.ToString(total);

            

            count++;
            txtCount.Text = Convert.ToString(count);
            txtScore.Text = Convert.ToString(score);

            average = total / count;
            txtAverage.Text = Convert.ToString(average);

            txtScore.Focus();
        }

        private void btnDisplayScore_Click(object sender, EventArgs e)
        {
            scoreList.Sort(); 

            string scoreString = "";
            foreach (int i in scoreList)
                if (i != 0)
                {
                    scoreString += i.ToString() + "\n";
                }
            MessageBox.Show(scoreString, "Sorted scores");
            txtScore.Focus();

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            total = 0;
            count = 0;
            average = 0;
            txtScore.Text = "";
            txtTotal.Text = "";
            txtCount.Text = "";
            txtAverage.Text = "";
            scoreList.Clear(); 
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
    
}

