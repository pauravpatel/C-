﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestScore8_1
{

    
    public partial class Form1 : Form
    {
        int total;
        int count;
        int average;
        int[] scoreArray = new int[20];

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
                    int score = int.Parse(txtScore.Text);

                    total += score;
                    txtScoreTotal.Text = Convert.ToString(total);

                    scoreArray[count] = score;

                    count++;
                    txtScoreCount.Text = Convert.ToString(count);

                    average = total / count;
                    txtAvg.Text = Convert.ToString(average);

                    txtScore.Focus();
                }
          

        private void btnDisplayScore_Click(object sender, EventArgs e)
        {
            Array.Sort(scoreArray);

            string scoreString = "";
            foreach(int i in scoreArray)
                if (i != 0)
                {
                    scoreString += i.ToString() + "\n";
                }
            MessageBox.Show(scoreString, "Sorted scores");
            txtScore.Focus();
  
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            total = 0;
            count = 0;
            average = 0;
            txtScore.Text = "";
            txtScoreTotal.Text = "";
            txtScoreCount.Text = "";
            txtAvg.Text = "";
            Array.Clear(scoreArray, 0,20);
            
        }

        private void txtScoreCount_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
