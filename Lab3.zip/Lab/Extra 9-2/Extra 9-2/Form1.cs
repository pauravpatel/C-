﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Extra_9_2
{
    public partial class Form1 : Form
    {

        string email;
   
        string city;
        string state;
        string zip; 


       
        public Form1()
        {
            InitializeComponent();
        }

        private void btnParse_Click(object sender, EventArgs e)
        {

            email = txtEmail.Text;

            if (email.Contains("@"))

            
                {
                    var userName = email.Substring(0, email.IndexOf('@'));
                    var domainName = email.Substring(email.IndexOf('@') + 1, email.Length - email.IndexOf('@') - 1);
                    MessageBox.Show("User name:" + userName + "\n" + "Domain Name:" + domainName, "Parsed String");
                }
     else
     {
                    MessageBox.Show("Invalid email");
                }
            }

        private void btnFormat_Click(object sender, EventArgs e)
        {
            city = txtCity.Text;
            state = txtState.Text;
            zip = txtZipcode.Text;

            MessageBox.Show("City, State, Zip: " + city + ", " + state.ToUpper() + " " + zip, "Formatted String");


        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }
    }
    }

