﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4_2
{
    public partial class ScoreCalculate : Form

        
    {

        Decimal scoreTotal = 0;
        Decimal scoreCount = 0;
        Decimal currentScore;
        Decimal Average; 
        

        public ScoreCalculate()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
             
            decimal score = Convert.ToDecimal(txtScore.Text);

            scoreTotal += score;

            txtTotal.Text = Convert.ToString(scoreTotal);

            scoreCount++;
            txtCount.Text = Convert.ToString(scoreCount);

            Average = scoreTotal / scoreCount;
            txtAverage.Text = Convert.ToString(Average);

            txtScore.Focus();


            

        }

        public class Utilities
        {
            public static void ResetAllControls(Control form)
            {
                foreach (Control control in form.Controls)
                {
                    if (control is TextBox)
                    {
                        TextBox textBox = (TextBox)control;
                        textBox.Text = null;
                    }

                }
            }
        }


        private void btnClear_Click(object sender, EventArgs e)
        {
            txtScore.Clear();
            txtTotal.Text = "";
            txtCount.Clear();
            txtCount.ResetText();
            txtTotal.Clear();
            txtAverage.Text = "";

            scoreTotal = 0;
            scoreCount = 0;
            

            

        }

                    private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void textScore_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
