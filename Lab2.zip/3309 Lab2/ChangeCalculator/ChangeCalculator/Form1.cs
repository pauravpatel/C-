﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChangeCalculator
{
    public partial class Form1 : Form
    {
        int Quarters = 25;
        int Dimes = 10;
        int Nickles = 5;
        int Pennies = 1; 

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblNickels_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)

        {
            int Amount = int.Parse(txtAmount.Text);

            if (Amount >= 25)
            {
                Quarters = Amount / 25;

                txtQuarters.Text = Quarters.ToString();
            }

            if (Amount >= 10)
            {
                Dimes = ((Amount % 25) / 10);
                txtDimes.Text = Dimes.ToString();
            }
            if (Amount >= 5)
            {
                Nickles = (((Amount % 25)% 10)/5);
                txtNickles.Text = Nickles.ToString();
            }
            if (Amount >= 1)
            {
                Pennies = ((((Amount % 25)%10)%5) / 1);
                txtPennies.Text = Pennies.ToString();
            }

            a = 0;
            
            int a = 10 / 25 + 50 / 2 - 1 / 2; 
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }
    }
    }

