﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Simple_Calculation
{
    public partial class SimpleCalculator : Form
    {
        public SimpleCalculator()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {


            try
            {
                decimal operand1 = decimal.Parse(txtOperand1.Text);
                decimal operand2 = decimal.Parse(txtOperand2.Text);
                string operator1 = txtOperator.Text;

                decimal result = Calculate(operand1, operand2, operator1);

                result = Math.Round(result, 4);
                txtResult.Text = result.ToString();
                txtOperand1.Focus(); 

            }

            catch (FormatException)
            
            {
                MessageBox.Show("Incorrect");
            }

            catch (DivideByZeroException)
            {
                MessageBox.Show("Invalid");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Error");
            }

        }


        private decimal Calculate (decimal operand1, decimal operand2, string operator1)

        {
            decimal result = 0;

            if (operator1 == "/")
                result = operand1 / operand2;
            else if (operator1 == "*")
                result = operand1 * operand2;
            else if (operator1 == "+")
                result = operand1 + operand2;
            else if (operator1 == "-")
                result = operand1 - operand2;

            return result; 

        }

        private void txtOperand1_TextChanged(object sender, EventArgs e)
        {
            txtResult.Clear();
        }

        private void txtOperand2_TextChanged(object sender, EventArgs e)
        {
            txtResult.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
