﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator7_2
{
    public partial class Form1 : Form


    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsValidData())

                {
                    decimal operand1 = decimal.Parse(txtOp1.Text);
                    decimal operand2 = decimal.Parse(txtOp2.Text);
                    string operator1 = txtOp.Text;
                    decimal result = Calculate(operand1, operand2, operator1);


                    result = Math.Round(result, 4);
                    txtResult.Text = result.ToString();
                    txtOp1.Focus();

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error"); 
            }

        }


        private decimal Calculate(decimal operand1, decimal operand2, string operator1)

        {
            decimal result = 0;

            if (operator1 == "/")
            {
                result = operand1 / operand2;
            }
            else if (operator1 == "*")
            {
                result = operand1 * operand2;
            }
            else if (operator1 == "+")
            {
                result = operand1 + operand2;
            }
            else if (operator1 == "-")
            {
                result = operand1 - operand2;
            }

            return result;

        }

        public bool IsOperator(TextBox txtOp, String Name)
        {


            if (!((txtOp.Text == "+") || (txtOp.Text == "-") || (txtOp.Text == "*") || (txtOp.Text == "/")))
            {
                MessageBox.Show("Operator is invalid");
                return false;

            }

            else
            {
                return true;
               
            }
        }

        public bool IsPresent(TextBox textBox, string name)

        {
            if (textBox.Text == "")

            {
                MessageBox.Show(textBox + "is a required filed");
                textBox.Focus();
                return false;
            }
            return true;

        }

        public bool IsDecimal(TextBox textBox, string name)

        {
            decimal number = 0m;

            if (Decimal.TryParse(textBox.Text, out number))

            {
                return true;
            }

            else

            {
                MessageBox.Show(textBox + " must be a decimal value");
                textBox.Focus();
                return false;
            }

        }

        public bool IsWithinRange(TextBox textBox, string name, decimal min, decimal max)
        {

            min = 0;
            max = 1000000;
            decimal number = Convert.ToDecimal(textBox.Text);

            if (number < min || number > max)

            {
                MessageBox.Show("must be between" + min.ToString() + "and" + max.ToString());
                textBox.Focus();
                return false;
            }

            return true;
        }


        public bool IsValidData()

        {
            return

                IsPresent(txtOp1, "Operand1") &&
                IsDecimal(txtOp1, "Operand1") &&
                IsWithinRange(txtOp1, "Operand1", 0, 100000) &&



                IsPresent(txtOp2, "Operand2") &&
                IsDecimal(txtOp2, "Operand2") &&
                IsWithinRange(txtOp2, "Operand2", 0, 100000) &&

                IsOperator(txtOp, "Operator");

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void txtResult_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
