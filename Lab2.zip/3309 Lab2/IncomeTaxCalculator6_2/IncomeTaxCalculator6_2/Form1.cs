﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IncomeTaxCalculator6_2
{
    public partial class IncomeTaxCalculator : Form
    {
        Decimal tax = 0;

        public IncomeTaxCalculator()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)


        {
            decimal input = decimal.Parse(txtIncome.Text);
            

             tax = CalculateTax(input);

            txtOwned.Text = Convert.ToString(tax);

        }

        private decimal CalculateTax (decimal input)
        {

            if ((input == 0) || (input <= 9225))

            {
                tax = (int)(input * .10m);

            }

            else if ((input >= 9225) || (input <= 37450))
            {

                tax = 922.50m + (int)((input - 9225) * .15m);

            }

            else if ((input >= 37450) || (input <= 90750))

            {
                tax = 5156.25m + (int)((input - 37450) * .25m);

            }
            else if ((input >= 90750) || input <= (189300))

            {
                tax = 18481.25m + (int)((input - 90750) * .28m);
            }

            else if ((input >= 189300) || (input <= 411500))

            {
                tax = 46075.25m + (int)((input - 189300) * .33m);

            }
            else if ((input >= 411500) || (input <= 413200))

            {
                tax = 119401.25m + (int)((input - 411500) * .35m);

            }
            else if (input >= 413200)

            {
                tax = 119996.25m + (int)((input - 413200) * .396m);

            }

            return tax;


        }





        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void txtIncome_TextChanged(object sender, EventArgs e)
        {
            txtOwned.Clear();
        }
    }
}
