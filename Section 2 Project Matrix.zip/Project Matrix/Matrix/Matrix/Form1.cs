﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Matrix
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        double[,] mA;
        double[,] mB;

        private void Form1_Load(object sender, EventArgs e)
        {
            rbnMultiply.Checked = true;
            txtRowA.Text = "3";
            txtColsA.Text = "3";
            txtRowB.Text = "3";
            txtColsB.Text = "3";
        }

        private void btnMatrixA_Click(object sender, EventArgs e)
        {
            mA = makeMatrix(txtRowA, txtColsA);
            txtMatrixA.Text = outputMatrix(mA);
        }

        private void btnMatrixB_Click(object sender, EventArgs e)
        {
            mB = makeMatrix(txtRowB, txtColsB);
            txtMatrixB.Text = outputMatrix(mB);
        }

        private void btnIdentityB_Click(object sender, EventArgs e)
        {
            if (mB != null)
            {
                if (mB.GetLength(0) == mB.GetLength(1))
                {
                    for (int i = 0; i < mB.GetLength(0); i++)
                    {
                        for (int j = 0; j < mB.GetLength(1); j++)
                            if (i == j)
                            {
                                mB[i, j] = 1.0;
                            }
                            else mB[i, j] = 0.0;
                    }
                    txtMatrixB.Text = outputMatrix(mB);
                }
                else
                {
                    MessageBox.Show("Check Rows and Cols of matrix, B must be equal", "Error");
                }
            }
            else
            {
                MessageBox.Show("Check input" , "Error");
            }
        }


        public double[,] makeMatrix(TextBox row, TextBox col)
        {
            double[,] matrix = new double[Convert.ToInt32(row.Text), Convert.ToInt32(col.Text)];
            Random autoRandom = new Random();
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                    matrix[i, j] = autoRandom.NextDouble() * 10.0;
            }
            return matrix;
        }

        public string outputMatrix(double[,] matrix)
        {
            string s = "";
            for (int i = 0; i < matrix.GetLength(0); ++i)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)

                    s += matrix[i, j].ToString("F2") + "\t";

                s += "\r\n";
            }
            return s;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (mA != null && mB != null)
            {
                if (rbnMultiply.Checked)
                {
                    if (mA.GetLength(0) == mB.GetLength(1) && mA.GetLength(1) == mB.GetLength(0))
                    {
                        int rA = mA.GetLength(0);
                        int cB = mB.GetLength(1);
                        double[,] mC = new double[rA, cB];
                        if (rbnMultiply.Checked == true)
                        {
                            for (int i = 0; i < rA; i++)
                            {
                                for (int j = 0; j < cB; j++)
                                {
                                    for (int k = 0; k < rA; k++)
                                    {
                                        mC[i, j] = mC[i, j] + mA[i, k] * mB[k, j];
                                    }

                                    txtMatrixC.Text = outputMatrix(mC);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Check Dimensions of A and B matrices");
                        }
                    }
                }
                else if (rbnAdd.Checked)
                {
                    if (mA.GetLength(0) == mB.GetLength(0) && mA.GetLength(1) == mB.GetLength(1))
                    {
                        int rA = mA.GetLength(0);
                        int cB = mB.GetLength(1);
                        double[,] mC = new double[rA, cB];
                        for (int i = 0; i < rA; i++)
                        {
                            for (int j = 0; j < cB; j++)
                            {
                                mC[i, j] = mA[i, j] + mB[i, j];
                            }
                            txtMatrixC.Text = outputMatrix(mC);
                        }
                    }

                    else
                    {
                        MessageBox.Show("Check Dimensions of A and B matrices must be equal");
                    }
                }
                else if (rbnSubtract.Checked)
                {
                    if (mA.GetLength(0) == mB.GetLength(0) && mA.GetLength(1) == mB.GetLength(1))
                    {
                        int rA = mA.GetLength(0);
                        int cB = mB.GetLength(1);
                        double[,] mC = new double[rA, cB];
                        for (int i = 0; i < rA; i++)
                        {
                            for (int j = 0; j < cB; j++)
                            {
                                mC[i, j] = mA[i, j] - mB[i, j];

                            }
                        }
                        txtMatrixC.Text = outputMatrix(mC);
                    }
                    else
                    {
                        MessageBox.Show("Check Dimensions of A and B matrices must be equal");
                    }

                }
                else
                {
                    MessageBox.Show("Check input: Initialize A and B matrix.", "Error");
                }
            }
      }
            
        

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtMatrixA.Text = "";
            txtMatrixB.Text = "";
            txtMatrixC.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void rbnAdd_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
    }




