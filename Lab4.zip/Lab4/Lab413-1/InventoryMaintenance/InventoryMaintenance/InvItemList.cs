﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryMaintenance
{
    public class InvItemList
    {
        private List<InvItem> invItems;

        public delegate void ChangedHandler(InvItemList invItem);
        public event ChangedHandler Changed = null;

        public InvItemList()
        {
            invItems = new List<InvItem>();
        }

        public int Count => invItems.Count;

        public InvItem this[int i]

        {
            

            get

            {
                if (i < 0 || i >= invItems.Count)

                {

                    throw new ArgumentOutOfRangeException(i.ToString());
                }

                return invItems[i]; 
            }
            set
            {
                invItems[i] = value;
                Changed(this);
            }

        }

        //public InvItem this[int itemNo]
        //{
        //    get
        //    {
        //        foreach (InvItem t in invItems)
        //        {

        //            if (t.ItemNo == itemNo)
        //                return t;
        //        }
        //        return null;
        //    }

        //}

        public void Fill() => invItems = InvItemDB.GetItems();

        public void Save() => InvItemDB.SaveItems(invItems);

        public void Add(InvItem invItem)

        {
            invItems.Add(invItem);
            Changed(this);
        }

        public void Add(int itemNo, string description, decimal price)

        {
            InvItem t = new InvItem(itemNo, description, price);

            invItems.Add(t);
            Changed(this); 

        }

        public void Remove(InvItem invItem)

        {
            invItems.Remove(invItem);
            Changed(this);
        }

        public static InvItemList operator +(InvItemList l1, InvItem l)
        {
            l1.Add(l);
            return l1; 

        }

        public static InvItemList operator -(InvItemList l1, InvItem l)
        {
            l1.Remove(l);
            return l1;

        }





        //    public InvItem GetItemByIndex(int i) => invItems[i];

        //    public void Add(InvItem invItem) => invItems.Add(invItem);

        //    public void Add(int itemNo, string description, decimal price)
        //    {
        //        InvItem i = new InvItem(itemNo, description, price);
        //        invItems.Add(i);
        //    }

        //    public void Remove(InvItem invItem) => invItems.Remove(invItem);


        //}
    }
}

