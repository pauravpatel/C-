﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Matrix2
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private Matrix mA;
        private Matrix mB;
        private Matrix mC;



        private void button1_Click(object sender, EventArgs e)
        {
            if (!object.Equals((object)this.mA, (object)null))
            {
                this.mB = this.mA.Clone();
                this.txtMatrixB.Text = this.mB.ToString();
            }
            else
            {
                int num = (int)MessageBox.Show("Matrix A is null");
            }
        }

        private void btnMatrixA_Click(object sender, EventArgs e)
        {
            try
            {
                this.mA = new Matrix(int.Parse(this.txtRowA.Text), int.Parse(this.txtColsA.Text));
                this.mA.PopulateRand();
                this.txtMatrixA.Text = this.mA.ToString();
            }
            catch (Exception)
            {
                int num = (int)MessageBox.Show("Parse error: ");
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            rbnMultiply.Checked = true;
            txtRowA.Text = "3";
            txtColsA.Text = "3";
            txtRowB.Text = "3";
            txtColsB.Text = "3";
        }

        private void btnMatrixB_Click(object sender, EventArgs e)
        {
            try
            {
                this.mB = new Matrix(int.Parse(this.txtRowB.Text), int.Parse(this.txtColsB.Text));
                this.mB.PopulateRand();
                this.txtMatrixB.Text = this.mB.ToString();
            }
            catch (Exception )
            {
                int num = (int)MessageBox.Show("Parse error: " );
            }
        }


        private void btnIdentityB_Click(object sender, EventArgs e)
        {
            int n = 0;
            try
            {
                if (this.txtRowB.Text == this.txtColsB.Text && this.txtColsB.Text != "")
                    n = int.Parse(this.txtColsB.Text);
                this.mB = Matrix.MakeID(n);
                this.txtMatrixB.Text = this.mB.ToString();
            }
            catch (Exception)
            {
                int num = (int)MessageBox.Show("Enter valid matrix size:" );
            }
        }


        public double[,] makeMatrix(TextBox row, TextBox col)
        {
            double[,] matrix = new double[Convert.ToInt32(row.Text), Convert.ToInt32(col.Text)];
            Random autoRandom = new Random();
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                    matrix[i, j] = autoRandom.NextDouble() * 10.0;
            }
            return matrix;
        }


        public string outputMatrix(double[,] matrix)
        {
            string s = "";
            for (int i = 0; i < matrix.GetLength(0); ++i)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)

                    s += matrix[i, j].ToString("F2") + "\t";

                s += "\r\n";
            }
            return s;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.rbnMultiply.Checked)
                {
                    this.mC = this.mA * this.mB;
                    this.txtMatrixC.Text = this.mC.ToString();
                }
                else if (this.rbnAdd.Checked)
                {
                    this.mC = this.mA + this.mB;
                    this.txtMatrixC.Text = this.mC.ToString();
                }
                else if (this.rbnSubtract.Checked)
                {
                    this.mC = this.mA - this.mB;
                    this.txtMatrixC.Text = this.mC.ToString();
                    
                }
                else
                {
                    if (!this.rbnEqual.Checked)
                        return;
                    this.txtMatrixC.Text = "";
                    if (this.mA == this.mB)
                        this.txtMatrixC.Text = "Matrix A is equal to Matrix B";
                    else
                        this.txtMatrixC.Text = "Matrix A is not equal to Matrix B";
                }
            }
            catch (Exception)
            {
                int num = (int)MessageBox.Show("Populate Matrix & try again");
            }
        }
        private void rbnEqual_CheckedChanged(object sender, EventArgs e)
        {
            if (!object.Equals((object)mA, (object)null))
            {
                this.mB = this.mA; 

                txtMatrixB.Text = mB.ToString();
            }
            else
            {
                int num = (int)MessageBox.Show("Matrix A is null");
            }
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtMatrixA.Text = "";
            txtMatrixB.Text = "";
            txtMatrixC.Text = "";
            mA= ((Matrix)null);
            mB =((Matrix)null);
            mC = ((Matrix)null);


        }

       


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

       
    }

}
