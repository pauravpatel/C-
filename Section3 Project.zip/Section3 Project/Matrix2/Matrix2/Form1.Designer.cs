﻿namespace Matrix2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatrixB = new System.Windows.Forms.TextBox();
            this.txtMatrixA = new System.Windows.Forms.TextBox();
            this.txtMatrixC = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbnEqual = new System.Windows.Forms.RadioButton();
            this.rbnSubtract = new System.Windows.Forms.RadioButton();
            this.rbnAdd = new System.Windows.Forms.RadioButton();
            this.rbnMultiply = new System.Windows.Forms.RadioButton();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnIdentityB = new System.Windows.Forms.Button();
            this.txtColsB = new System.Windows.Forms.TextBox();
            this.txtRowB = new System.Windows.Forms.TextBox();
            this.txtColsA = new System.Windows.Forms.TextBox();
            this.txtRowA = new System.Windows.Forms.TextBox();
            this.btnMatrixB = new System.Windows.Forms.Button();
            this.btnMatrixA = new System.Windows.Forms.Button();
            this.lblCols = new System.Windows.Forms.Label();
            this.lblRows = new System.Windows.Forms.Label();
            this.lblMatrixC = new System.Windows.Forms.Label();
            this.lblMatrixB = new System.Windows.Forms.Label();
            this.lblMatrixA = new System.Windows.Forms.Label();
            this.btnCopy = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatrixB
            // 
            this.txtMatrixB.Location = new System.Drawing.Point(185, 46);
            this.txtMatrixB.Multiline = true;
            this.txtMatrixB.Name = "txtMatrixB";
            this.txtMatrixB.ReadOnly = true;
            this.txtMatrixB.Size = new System.Drawing.Size(150, 150);
            this.txtMatrixB.TabIndex = 77;
            this.txtMatrixB.TabStop = false;
            // 
            // txtMatrixA
            // 
            this.txtMatrixA.Location = new System.Drawing.Point(21, 46);
            this.txtMatrixA.Multiline = true;
            this.txtMatrixA.Name = "txtMatrixA";
            this.txtMatrixA.ReadOnly = true;
            this.txtMatrixA.Size = new System.Drawing.Size(150, 150);
            this.txtMatrixA.TabIndex = 76;
            this.txtMatrixA.TabStop = false;
            // 
            // txtMatrixC
            // 
            this.txtMatrixC.Location = new System.Drawing.Point(353, 46);
            this.txtMatrixC.Multiline = true;
            this.txtMatrixC.Name = "txtMatrixC";
            this.txtMatrixC.ReadOnly = true;
            this.txtMatrixC.Size = new System.Drawing.Size(150, 150);
            this.txtMatrixC.TabIndex = 78;
            this.txtMatrixC.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(406, 369);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 75;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbnEqual);
            this.groupBox1.Controls.Add(this.rbnSubtract);
            this.groupBox1.Controls.Add(this.rbnAdd);
            this.groupBox1.Controls.Add(this.rbnMultiply);
            this.groupBox1.Location = new System.Drawing.Point(21, 297);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(352, 47);
            this.groupBox1.TabIndex = 74;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Operation";
            // 
            // rbnEqual
            // 
            this.rbnEqual.AutoSize = true;
            this.rbnEqual.Location = new System.Drawing.Point(211, 19);
            this.rbnEqual.Name = "rbnEqual";
            this.rbnEqual.Size = new System.Drawing.Size(51, 17);
            this.rbnEqual.TabIndex = 3;
            this.rbnEqual.Text = "A==B";
            this.rbnEqual.UseVisualStyleBackColor = true;
            this.rbnEqual.CheckedChanged += new System.EventHandler(this.rbnEqual_CheckedChanged);
            // 
            // rbnSubtract
            // 
            this.rbnSubtract.AutoSize = true;
            this.rbnSubtract.Location = new System.Drawing.Point(132, 19);
            this.rbnSubtract.Name = "rbnSubtract";
            this.rbnSubtract.Size = new System.Drawing.Size(65, 17);
            this.rbnSubtract.TabIndex = 2;
            this.rbnSubtract.Text = "Subtract";
            this.rbnSubtract.UseVisualStyleBackColor = true;
            // 
            // rbnAdd
            // 
            this.rbnAdd.AutoSize = true;
            this.rbnAdd.Location = new System.Drawing.Point(82, 19);
            this.rbnAdd.Name = "rbnAdd";
            this.rbnAdd.Size = new System.Drawing.Size(44, 17);
            this.rbnAdd.TabIndex = 1;
            this.rbnAdd.Text = "Add";
            this.rbnAdd.UseVisualStyleBackColor = true;
            // 
            // rbnMultiply
            // 
            this.rbnMultiply.AutoSize = true;
            this.rbnMultiply.Checked = true;
            this.rbnMultiply.Location = new System.Drawing.Point(16, 19);
            this.rbnMultiply.Name = "rbnMultiply";
            this.rbnMultiply.Size = new System.Drawing.Size(60, 17);
            this.rbnMultiply.TabIndex = 0;
            this.rbnMultiply.TabStop = true;
            this.rbnMultiply.Text = "Multiply";
            this.rbnMultiply.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(288, 369);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(99, 23);
            this.btnClear.TabIndex = 73;
            this.btnClear.Text = "Clear Matrices";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(21, 369);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 72;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnIdentityB
            // 
            this.btnIdentityB.Location = new System.Drawing.Point(383, 255);
            this.btnIdentityB.Name = "btnIdentityB";
            this.btnIdentityB.Size = new System.Drawing.Size(98, 23);
            this.btnIdentityB.TabIndex = 71;
            this.btnIdentityB.Text = "Make B Identity";
            this.btnIdentityB.UseVisualStyleBackColor = true;
            this.btnIdentityB.Click += new System.EventHandler(this.btnIdentityB_Click);
            // 
            // txtColsB
            // 
            this.txtColsB.Location = new System.Drawing.Point(273, 258);
            this.txtColsB.Name = "txtColsB";
            this.txtColsB.Size = new System.Drawing.Size(100, 20);
            this.txtColsB.TabIndex = 63;
            // 
            // txtRowB
            // 
            this.txtRowB.Location = new System.Drawing.Point(157, 258);
            this.txtRowB.Name = "txtRowB";
            this.txtRowB.Size = new System.Drawing.Size(100, 20);
            this.txtRowB.TabIndex = 62;
            // 
            // txtColsA
            // 
            this.txtColsA.Location = new System.Drawing.Point(273, 220);
            this.txtColsA.Name = "txtColsA";
            this.txtColsA.Size = new System.Drawing.Size(100, 20);
            this.txtColsA.TabIndex = 61;
            // 
            // txtRowA
            // 
            this.txtRowA.Location = new System.Drawing.Point(157, 220);
            this.txtRowA.Name = "txtRowA";
            this.txtRowA.Size = new System.Drawing.Size(100, 20);
            this.txtRowA.TabIndex = 60;
            // 
            // btnMatrixB
            // 
            this.btnMatrixB.Location = new System.Drawing.Point(24, 258);
            this.btnMatrixB.Name = "btnMatrixB";
            this.btnMatrixB.Size = new System.Drawing.Size(117, 23);
            this.btnMatrixB.TabIndex = 70;
            this.btnMatrixB.Text = "Make Matrix B";
            this.btnMatrixB.UseVisualStyleBackColor = true;
            this.btnMatrixB.Click += new System.EventHandler(this.btnMatrixB_Click);
            // 
            // btnMatrixA
            // 
            this.btnMatrixA.Location = new System.Drawing.Point(24, 220);
            this.btnMatrixA.Name = "btnMatrixA";
            this.btnMatrixA.Size = new System.Drawing.Size(117, 23);
            this.btnMatrixA.TabIndex = 69;
            this.btnMatrixA.Text = "Make Matrix A";
            this.btnMatrixA.UseVisualStyleBackColor = true;
            this.btnMatrixA.Click += new System.EventHandler(this.btnMatrixA_Click);
            // 
            // lblCols
            // 
            this.lblCols.AutoSize = true;
            this.lblCols.Location = new System.Drawing.Point(270, 199);
            this.lblCols.Name = "lblCols";
            this.lblCols.Size = new System.Drawing.Size(27, 13);
            this.lblCols.TabIndex = 68;
            this.lblCols.Text = "Cols";
            // 
            // lblRows
            // 
            this.lblRows.AutoSize = true;
            this.lblRows.Location = new System.Drawing.Point(154, 199);
            this.lblRows.Name = "lblRows";
            this.lblRows.Size = new System.Drawing.Size(34, 13);
            this.lblRows.TabIndex = 67;
            this.lblRows.Text = "Rows";
            // 
            // lblMatrixC
            // 
            this.lblMatrixC.AutoSize = true;
            this.lblMatrixC.Location = new System.Drawing.Point(350, 30);
            this.lblMatrixC.Name = "lblMatrixC";
            this.lblMatrixC.Size = new System.Drawing.Size(45, 13);
            this.lblMatrixC.TabIndex = 66;
            this.lblMatrixC.Text = "Matrix C";
            // 
            // lblMatrixB
            // 
            this.lblMatrixB.AutoSize = true;
            this.lblMatrixB.Location = new System.Drawing.Point(182, 30);
            this.lblMatrixB.Name = "lblMatrixB";
            this.lblMatrixB.Size = new System.Drawing.Size(45, 13);
            this.lblMatrixB.TabIndex = 65;
            this.lblMatrixB.Text = "Matrix B";
            // 
            // lblMatrixA
            // 
            this.lblMatrixA.AutoSize = true;
            this.lblMatrixA.Location = new System.Drawing.Point(21, 30);
            this.lblMatrixA.Name = "lblMatrixA";
            this.lblMatrixA.Size = new System.Drawing.Size(45, 13);
            this.lblMatrixA.TabIndex = 64;
            this.lblMatrixA.Text = "Matrix A";
            // 
            // btnCopy
            // 
            this.btnCopy.Location = new System.Drawing.Point(383, 217);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(120, 23);
            this.btnCopy.TabIndex = 79;
            this.btnCopy.Text = "Make B Copy of A";
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 422);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.txtMatrixB);
            this.Controls.Add(this.txtMatrixA);
            this.Controls.Add(this.txtMatrixC);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnIdentityB);
            this.Controls.Add(this.txtColsB);
            this.Controls.Add(this.txtRowB);
            this.Controls.Add(this.txtColsA);
            this.Controls.Add(this.txtRowA);
            this.Controls.Add(this.btnMatrixB);
            this.Controls.Add(this.btnMatrixA);
            this.Controls.Add(this.lblCols);
            this.Controls.Add(this.lblRows);
            this.Controls.Add(this.lblMatrixC);
            this.Controls.Add(this.lblMatrixB);
            this.Controls.Add(this.lblMatrixA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatrixB;
        private System.Windows.Forms.TextBox txtMatrixA;
        private System.Windows.Forms.TextBox txtMatrixC;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbnSubtract;
        private System.Windows.Forms.RadioButton rbnAdd;
        private System.Windows.Forms.RadioButton rbnMultiply;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnIdentityB;
        private System.Windows.Forms.TextBox txtColsB;
        private System.Windows.Forms.TextBox txtRowB;
        private System.Windows.Forms.TextBox txtColsA;
        private System.Windows.Forms.TextBox txtRowA;
        private System.Windows.Forms.Button btnMatrixB;
        private System.Windows.Forms.Button btnMatrixA;
        private System.Windows.Forms.Label lblCols;
        private System.Windows.Forms.Label lblRows;
        private System.Windows.Forms.Label lblMatrixC;
        private System.Windows.Forms.Label lblMatrixB;
        private System.Windows.Forms.Label lblMatrixA;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.RadioButton rbnEqual;
    }
}

