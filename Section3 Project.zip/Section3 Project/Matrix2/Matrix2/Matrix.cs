﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matrix2
{
     internal class Matrix
    {
         double[,] matrix;

        public Matrix(int x, int y)
        {
            matrix = new double[x, y];
        }

        public double this[int i, int j]
        {
            get
            {
                return matrix[i, j];
            }
            set
            {
                matrix[i, j] = value;
            }
        }

        public int Rows
        {
            get
            {
                return matrix.GetLength(0);
            }
        }

        public int Cols
        {
            get
            {
                return matrix.GetLength(1);
            }
        }

        public void PopulateRand()
        {
            Random random = new Random();
            for (int index1 = 0; index1 < Rows; ++index1)
            {
                for (int index2 = 0; index2 < Cols; ++index2)
                    matrix[index1, index2] = random.NextDouble() * 10.0;
            }
        }

        public void PopulateOrd()
        {
            double num = 1.0;
            for (int index1 = 0; index1 < Rows; ++index1)
            {
                for (int index2 = 0; index2 < Cols; ++index2)
                {
                    matrix[index1, index2] = num;
                    ++num;
                }
            }
        }

        public bool RowsEqual(Matrix m)
        {
            return m.Rows == Rows;
        }

        public bool colsEqual(Matrix m)
        {
            return m.Cols == Cols;
        }

        public bool DimsEqual(Matrix m)
        {
            return m.Rows == Rows || m.Cols == Cols;
        }

        public override bool Equals(object o)
        {
            if (o == null)
                return false;
            Matrix m = (Matrix)o;
            if (!RowsEqual(m) || !colsEqual(m))
                return false;
            for (int index1 = 0; index1 < Rows; ++index1)
            {
                for (int index2 = 0; index2 < Cols; ++index2)
                {
                    if (m[index1, index2] != matrix[index1, index2])
                        return false;
                }
            }
            return true;
        }

        public override int GetHashCode()
        {
            return Sum().GetHashCode();
        }

        public double Sum()
        {
            double num = 0.0;
            for (int index1 = 0; index1 < Rows; ++index1)
            {
                for (int index2 = 0; index2 < Cols; ++index2)
                    num += matrix[index1, index2];
            }
            return num;
        }


        public Matrix Add(Matrix m)
        {
            if (object.Equals((object)m, (object)null))
                throw new ArgumentNullException("Matrix is null");
            if (!DimsEqual(m))
                throw new ArgumentException("Error");
            Matrix matrix = new Matrix(Rows, Cols);
            for (int index1 = 0; index1 < Rows; ++index1)
            {
                for (int index2 = 0; index2 < Cols; ++index2)
                    matrix[index1, index2] = this[index1, index2] + m[index1, index2];
            }
            return matrix;
        }

        public Matrix subtract(Matrix m)
        {
            if (object.Equals((object)m, (object)null))
                throw new ArgumentNullException("Matrix is null");
            if (!DimsEqual(m))
                throw new ArgumentException("Error");
            Matrix matrix = new Matrix(Rows, Cols);
            for (int index1 = 0; index1 < Rows; ++index1)
            {
                for (int index2 = 0; index2 < Cols; ++index2)
                    matrix[index1, index2] = this[index1, index2] - m[index1, index2];
            }
            return matrix;
        }

        public Matrix Multiply(Matrix m)
        {
            if (object.Equals((object)m, (object)null))
                throw new ArgumentNullException("Matrix is null");
            if (!DimsEqual(m))
                throw new ArgumentException("Error");
            Matrix matrix1 = new Matrix(Rows, Cols);
            for (int index1 = 0; index1 < Rows; ++index1)
            {
                for (int index2 = 0; index2 < Cols; ++index2)
                {
                    for (int index3 = 0; index3 < Rows; ++index3)
                    {
                        Matrix matrix2 = matrix1;
                        int index4 = index1;
                        int index5 = index2;
                        matrix2[index4, index5] = matrix2[index4, index5] + this[index1, index3] * m[index3, index2];
                    }
                }
            }
            return matrix1;
        }

        public static bool operator ==(Matrix m1, Matrix m2)
        {
            if (!object.Equals((object)m1, (object)null))
                return m1.Equals((object)m2);
            return object.Equals((object)m2, (object)null);
        }

        public static bool operator !=(Matrix m1, Matrix m2)
        {
            return !(m1 == m2);
        }

        public static Matrix operator *(Matrix m1, Matrix m2)
        {
            if (object.Equals((object)m1, (object)null) || object.Equals((object)m2, (object)null))
                throw new ArgumentNullException("One or both vectors are null");
            if (m1.Rows != m2.Cols || m1.Cols != m2.Rows)
                throw new ArgumentException("mismatch");
            return m1.Multiply(m2);
        }

        public static Matrix operator +(Matrix m1, Matrix m2)
        {
            if (object.Equals((object)m1, (object)null) || object.Equals((object)m2, (object)null))
                throw new ArgumentNullException("One or both vectors are null");
            if (!m1.DimsEqual(m2))
                throw new ArgumentException("mismatch");
            return m1.Add(m2);
        }

        public static Matrix operator -(Matrix m1, Matrix m2)
        {
            if (object.Equals((object)m1, (object)null) || object.Equals((object)m2, (object)null))
                throw new ArgumentNullException("One or both vectors are null");
            if (!m1.DimsEqual(m2))
                throw new ArgumentException("mismatch");
            return m1.subtract(m2);
        }

        public Matrix Clone()
        {
            Matrix matrix = new Matrix(Rows, Cols);
            for (int index1 = 0; index1 < Rows; ++index1)
            {
                for (int index2 = 0; index2 < Cols; ++index2)
                    matrix[index1, index2] = this.matrix[index1, index2];
            }
            return matrix;
        }

        public void Clone(Matrix m)
        {
            for (int index1 = 0; index1 < Rows; ++index1)
            {
                for (int index2 = 0; index2 < Cols; ++index2)
                    matrix[index1, index2] = m[index1, index2];
            }
        }

        public override string ToString()
        {
            string str = "";
            for (int index1 = 0; index1 < Rows; ++index1)
            {
                for (int index2 = 0; index2 < Cols; ++index2)
                    str = str + matrix[index1, index2].ToString("F1") + "\t";
                str += "\r\n";
            }
            return str;
        }

        public static Matrix MakeID(int n)
        {
            Matrix matrix = new Matrix(n, n);
            for (int index1 = 0; index1 < matrix.Rows; ++index1)
            {
                for (int index2 = 0; index2 < matrix.Cols; ++index2)
                    matrix[index1, index2] = index1 != index2 ? 0.0 : 1.0;
            }
            return matrix;
        }
    }

}
