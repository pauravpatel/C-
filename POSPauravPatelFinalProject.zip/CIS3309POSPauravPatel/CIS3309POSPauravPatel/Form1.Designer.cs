﻿namespace CIS3309POSPauravPatel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPRoductID = new System.Windows.Forms.TextBox();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lblProductID = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.btnRemoveProduct = new System.Windows.Forms.Button();
            this.btnGetDescription = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnCancelSale = new System.Windows.Forms.Button();
            this.btnEnterSale = new System.Windows.Forms.Button();
            this.btnSearchProducts = new System.Windows.Forms.Button();
            this.lblScreen = new System.Windows.Forms.Label();
            this.txtReceipt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lstScreen = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txtPRoductID
            // 
            this.txtPRoductID.Location = new System.Drawing.Point(21, 35);
            this.txtPRoductID.Name = "txtPRoductID";
            this.txtPRoductID.Size = new System.Drawing.Size(100, 20);
            this.txtPRoductID.TabIndex = 0;
            this.txtPRoductID.TextChanged += new System.EventHandler(this.txtPRoductID_TextChanged);
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(21, 81);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(100, 20);
            this.txtQuantity.TabIndex = 1;
            // 
            // lblProductID
            // 
            this.lblProductID.AutoSize = true;
            this.lblProductID.Location = new System.Drawing.Point(21, 19);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(55, 13);
            this.lblProductID.TabIndex = 2;
            this.lblProductID.Text = "ProductID";
            this.lblProductID.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(21, 65);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(46, 13);
            this.lblQuantity.TabIndex = 3;
            this.lblQuantity.Text = "Quantity";
            // 
            // btnRemoveProduct
            // 
            this.btnRemoveProduct.Location = new System.Drawing.Point(21, 117);
            this.btnRemoveProduct.Name = "btnRemoveProduct";
            this.btnRemoveProduct.Size = new System.Drawing.Size(237, 23);
            this.btnRemoveProduct.TabIndex = 4;
            this.btnRemoveProduct.Text = "Remove Selected Product\r\n";
            this.btnRemoveProduct.UseVisualStyleBackColor = true;
            this.btnRemoveProduct.Click += new System.EventHandler(this.btnRemoveProduct_Click);
            // 
            // btnGetDescription
            // 
            this.btnGetDescription.Location = new System.Drawing.Point(148, 35);
            this.btnGetDescription.Name = "btnGetDescription";
            this.btnGetDescription.Size = new System.Drawing.Size(110, 23);
            this.btnGetDescription.TabIndex = 5;
            this.btnGetDescription.Text = "Get Description";
            this.btnGetDescription.UseVisualStyleBackColor = true;
            this.btnGetDescription.Click += new System.EventHandler(this.btnGetDescription_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Location = new System.Drawing.Point(148, 81);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(110, 23);
            this.btnAddProduct.TabIndex = 6;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnCancelSale
            // 
            this.btnCancelSale.Location = new System.Drawing.Point(21, 166);
            this.btnCancelSale.Name = "btnCancelSale";
            this.btnCancelSale.Size = new System.Drawing.Size(113, 41);
            this.btnCancelSale.TabIndex = 7;
            this.btnCancelSale.Text = "Cancel Sale";
            this.btnCancelSale.UseVisualStyleBackColor = true;
            this.btnCancelSale.Click += new System.EventHandler(this.btnCancelSale_Click);
            // 
            // btnEnterSale
            // 
            this.btnEnterSale.Location = new System.Drawing.Point(140, 166);
            this.btnEnterSale.Name = "btnEnterSale";
            this.btnEnterSale.Size = new System.Drawing.Size(118, 41);
            this.btnEnterSale.TabIndex = 8;
            this.btnEnterSale.Text = "Enter Sale";
            this.btnEnterSale.UseVisualStyleBackColor = true;
            this.btnEnterSale.Click += new System.EventHandler(this.btnEnterSale_Click);
            // 
            // btnSearchProducts
            // 
            this.btnSearchProducts.Location = new System.Drawing.Point(21, 246);
            this.btnSearchProducts.Name = "btnSearchProducts";
            this.btnSearchProducts.Size = new System.Drawing.Size(132, 23);
            this.btnSearchProducts.TabIndex = 9;
            this.btnSearchProducts.Text = "Search Product";
            this.btnSearchProducts.UseVisualStyleBackColor = true;
            this.btnSearchProducts.Click += new System.EventHandler(this.btnSearchProducts_Click);
            // 
            // lblScreen
            // 
            this.lblScreen.AutoSize = true;
            this.lblScreen.Location = new System.Drawing.Point(261, 10);
            this.lblScreen.Name = "lblScreen";
            this.lblScreen.Size = new System.Drawing.Size(41, 13);
            this.lblScreen.TabIndex = 11;
            this.lblScreen.Text = "Screen";
            // 
            // txtReceipt
            // 
            this.txtReceipt.Location = new System.Drawing.Point(568, 35);
            this.txtReceipt.Multiline = true;
            this.txtReceipt.Name = "txtReceipt";
            this.txtReceipt.ReadOnly = true;
            this.txtReceipt.Size = new System.Drawing.Size(305, 342);
            this.txtReceipt.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(829, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Receipt";
            // 
            // lstScreen
            // 
            this.lstScreen.FormattingEnabled = true;
            this.lstScreen.Location = new System.Drawing.Point(264, 35);
            this.lstScreen.Name = "lstScreen";
            this.lstScreen.Size = new System.Drawing.Size(298, 342);
            this.lstScreen.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(937, 395);
            this.Controls.Add(this.lstScreen);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtReceipt);
            this.Controls.Add(this.lblScreen);
            this.Controls.Add(this.btnSearchProducts);
            this.Controls.Add(this.btnEnterSale);
            this.Controls.Add(this.btnCancelSale);
            this.Controls.Add(this.btnAddProduct);
            this.Controls.Add(this.btnGetDescription);
            this.Controls.Add(this.btnRemoveProduct);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.lblProductID);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.txtPRoductID);
            this.Name = "Form1";
            this.Text = "Product POS";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPRoductID;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Button btnRemoveProduct;
        private System.Windows.Forms.Button btnGetDescription;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnCancelSale;
        private System.Windows.Forms.Button btnEnterSale;
        private System.Windows.Forms.Button btnSearchProducts;
        private System.Windows.Forms.Label lblScreen;
        private System.Windows.Forms.TextBox txtReceipt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstScreen;
    }
}

