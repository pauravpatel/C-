﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS3309POSPauravPatel
{
    public partial class frmSearch : Form
    {
        ArrayList pro = new ArrayList();//ArrayList for data search 

        public frmSearch()
        {
            InitializeComponent();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            btnSearch.Text = "Search"; 
        }

        //this method uses the like query to search data from the database 

        private void btnSearch_Click(object sender, EventArgs e)//search button 
        {
            if (txtSearch.Text != "" && btnSearch.Text == "Search")
            {
                lstSearch.Items.Clear();
                pro = ProductDB.SelectLikeDesc(txtSearch.Text);
                if (pro.Count != 0)
                {
                    foreach (Product product in pro)
                    {
                        if (product != null)
                        {
                            lstSearch.Items.Add(product.ToString());
                            btnSearch.Text = "Copy ID to POS";// copys id to pos 
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No Records Found"); //if nothing found in db prints message no record
                }
            }
            else if (btnSearch.Text == "Copy ID to POS") 
            {
                if (lstSearch.SelectedIndex >= 0)
                {
                    Tag = this.pro[lstSearch.SelectedIndex];
                    this.Close();
                }
                else
                {
                    MessageBox.Show("No item selected. Please select an item in the list box.");
                }
            }
            else
            {
                return;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)//exit
        {
            this.pro = null;
            this.Tag = this.pro;
            this.Close();
        }

        private void frmSearch_Load(object sender, EventArgs e)
        {

        }
    }
}
