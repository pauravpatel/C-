﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS3309POSPauravPatel
{
    public partial class Form1 : Form
    {
        private Transaction trans;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnGetDescription_Click(object sender, EventArgs e)
            //get description methods gets the desc for the produt that is being search by the use from the Productdb. 
        {

            if (txtPRoductID.Text != "")
            {

                Product product = ProductDB.SelectProduct(this.txtPRoductID.Text);
                Product originalProduct = null;

                if (product != null)//checks product from different category ex movie, music, software etc
                {
                    MessageBox.Show("Product: " + product.ToString());
                    if (product.Type == "Movie")
                        originalProduct = ProductDB.SelectMovie(product.ID);
                    if (product.Type == "Music")
                        originalProduct = ProductDB.SelectMusic(product.ID);
                    if (product.Type == "Software")
                        originalProduct = ProductDB.SelectSoftware(product.ID);
                    if (product.Type == "Pants")
                        originalProduct = ProductDB.SelectPants(product.ID);
                    if (product.Type == "DressShirt")
                        originalProduct = ProductDB.SelectDressShirt(product.ID);
                    if (product.Type == "TShirt")
                        originalProduct = ProductDB.SelectTShirt(product.ID);
                    if (product.Type == "Book")
                        originalProduct = ProductDB.SelectBook(product.ID);
                }

                if (originalProduct != null)
                {
                    Form frm = new frmProduct();//if prodcuts not found prints error msg 
                    frm.Tag = originalProduct;
                    frm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Product: " + txtPRoductID.Text + " not found. Check input and try again");//if input is in correct print this error msg 
                }
            }
            else
            {
                MessageBox.Show("Product ID is empty.Enter correct Product ID.");//if product txt is empty
            }

        }

        private void btnAddProduct_Click(object sender, EventArgs e) //add prduct method adds the product depending on the qty added by the user
        {


            int qty = 0;

            try 
            {
                if (txtPRoductID.Text != "")
                {
                    if (txtQuantity.Text != "" && Convert.ToInt32(txtQuantity.Text) > 0)
                    {
                        try
                        {
                            qty = Convert.ToInt32(txtQuantity.Text);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                            return;
                        }
                        Product p = ProductDB.SelectProduct(txtPRoductID.Text);
                        if (p != null)// checks if qty eneterd is not null
                        {
                            double total = p.Price * qty;
                            lstScreen.Items.Add((p.ID + "  " + p.Desc + "  " + qty + " @ " + p.Price.ToString("C") + " -> " + total.ToString("C")));
                            // prints id + description + qty and total price
                            trans.Add(p, qty);
                            txtPRoductID.Clear(); //clear ProductID
                            txtQuantity.Clear(); //clear Quantity
                        }
                    }
                    else
                    {
                        MessageBox.Show(" Check Qty. Qty cannot be less than 0. Enter Qty greater than 0.");//prints the error msg if unput is incorrect. 
                    }

                }
                else
                {
                    MessageBox.Show("Product ID is empty.Enter valid Product ID.");//if text box is left empty print this msg
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnRemoveProduct_Click(object sender, EventArgs e)
        {
            if (lstScreen.SelectedIndex >= 0)
            {
                trans.RemoveAt(lstScreen.SelectedIndex);// this removes product from the 1st screen that is printed
                lstScreen.Items.RemoveAt(lstScreen.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Unable to remove product or product selected. Select a valid product.");
            }
        }

        private void btnCancelSale_Click(object sender, EventArgs e)
        {
            trans.Clear();//clears the sale 
            lstScreen.Items.Clear();
        }

        private void btnEnterSale_Click(object sender, EventArgs e)//Button enter sale prints final sale from 1st screen to 2nd where receipt is printed
        {
            double subtotal = 0.0;
            double tax = 0.06;// tax to be added to every transcartion 
            if (lstScreen.Items.Count > 0)
            {
                for (int i = 0; i < lstScreen.Items.Count; i++)
                {
                    subtotal += trans.ProductAt(i).Price * trans.QtyOfProductsAt(i); //calaculate the amt of qty  and times by the price of the product
                }

                tax = tax * subtotal;//adds tax to the price
                double total = tax + subtotal;//prints total including taxes

                ProductDB.InsertTrans(subtotal, tax, total);
                int transID = ProductDB.SelectMaxTrans();

                string receiptStr = "Paurav's Recipt\r\n\r\n\r\n" + // prints the name on the top of the receipt
                    DateTime.Now.ToLongDateString() + " at " + DateTime.Now.ToLongTimeString() + "\r\n\r\n\r\n"; // gets the current date and time so that it can be printed 
                for (int i = 0; i < lstScreen.Items.Count; i++)
                {
                    int qty = trans.ProductAt(i).Qty - trans.QtyOfProductsAt(i); 
                    ProductDB.InsertLineItem(transID, trans.ProductAt(i).ID, trans.QtyOfProductsAt(i), trans.ProductAt(i).Price);
                    ProductDB.UpdateProduct(trans.ProductAt(i).ID, qty);
                    receiptStr += trans.ProductAt(i).ID + "  " + trans.ProductAt(i).Desc + "  " + trans.ProductAt(i).Qty + " @ " + trans.ProductAt(i).Price.ToString("C") + " -> " + (trans.ProductAt(i).Price * trans.QtyOfProductsAt(i)).ToString("C") + "\r\n";
                }

                receiptStr += "\r\nSubtotal\t\t\t\t" + subtotal.ToString("C") + "\r\nTax\t\t\t\t" + tax.ToString("C") + "\r\nTotal\t\t\t\t" + total.ToString("C"); // prints subtotle, tax and total 
                txtReceipt.Text = receiptStr;
                trans.Clear();//clears transactions
                lstScreen.Items.Clear();//clears 1st screen
            }
            else
            {
                MessageBox.Show("Screen is empty.");
                return;
            }
        }

        private void btnSearchProducts_Click(object sender, EventArgs e)
            // button search is for searching the product from the 
            //Productdb depending on the keywotrds entered by the user. 
        {
            Form form = new frmSearch();
            form.ShowDialog();
            if (form.Tag != null) 
            {
                this.txtPRoductID.Text = ((Product)form.Tag).ID;
            }
            else
            {
                return;
            }
        }

        private void Form1_Load(object sender, EventArgs e) //on load 
        {
            this.trans = new Transaction();//if form is is reloaded on reopned it will start 
            //from 0 no last transctions will continue 
        }

        private void txtPRoductID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

