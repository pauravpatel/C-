﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS3309POSPauravPatel
{
    class ProductDB
    {
        // This method returns a DB connection
        public static OleDbConnection GetConnection()
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + //conection string 
                "Data Source=|DataDirectory|\\ProductDB.accdb;" +
                "Persist Security Info=True";
            OleDbConnection connection = new OleDbConnection(connectionString);
            return connection;
        }


        public static bool ExeNonQuery(string sqlString)
            //executes insert and upadte query
        {
            OleDbConnection connection = GetConnection();

            OleDbCommand command = new OleDbCommand(sqlString, connection); 

            try
            {
                // Open connection
                connection.Open();
                

                int count = command.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                throw ex;
            }
            finally
            {
                //connection close 
                connection.Close();
            }

        }


        public static Product SelectProduct(String productID)
        {
            OleDbConnection connection = GetConnection();
            string selectStatement = "SELECT ID, Desc, Price, Qty, Type " +  //select statement for Product table. Gets produt id, des, price, qty & type
                "From Product Where ID = '" + productID + "'";
            OleDbCommand selectCommand = new OleDbCommand(selectStatement, connection);

            try
            {
                //open connection
                connection.Open();

                // Use command to execute a query with results in reader
                OleDbDataReader reader = selectCommand.ExecuteReader();
                if (reader.Read())
                {
                    // Instantiate and copy data from reader
                    Product p = new Product(); 
                    p.ID = reader.GetString(0);//gets product id 
                    p.Desc = reader.GetString(1);//gets product desc 
                    p.Price = reader.GetDouble(2);//gets productprice 
                    p.Qty = reader.GetInt32(3);//gets product qty
                    p.Type = reader.GetString(4);// gets product type 
                    return p;
                }
                else
                {
                    return null;
                }
            }
            catch (OleDbException ex)
            {
                throw ex;
            }
            finally
            {
                //connection close
                connection.Close();
            }
        }

        public static Pants SelectPants(string id)
        {
            Pants p = null;

            OleDbConnection connection = GetConnection();

            string select = "SELECT Product.ID, Product.Desc, Product.Price, "     //slect statement with inner join from table pants 
                + "Product.Qty, Product.Type, Apparel.Material, Apparel.Color, Apparel.Manufacturer, "    
                + "Pants.Waist, Pants.Inseam FROM (Product INNER JOIN Apparel ON Product.ID = Apparel.ID)"
                + "INNER JOIN Pants ON Apparel.ID = Pants.ID WHERE Product.ID = '" + id + "';";

            OleDbCommand command = new OleDbCommand(select, connection);
            try
            {
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    p = new Pants();
                    // Instantiate and copy data from reader                   
                    p.ID = reader.GetString(0);
                    p.Desc = reader.GetString(1);
                    p.Price = reader.GetDouble(2);
                    p.Qty = reader.GetInt32(3);
                    p.Type = reader.GetString(4);
                    p.Material = reader.GetString(5);
                    p.Color = reader.GetString(6);
                    p.Manufacturer = reader.GetString(7);
                    p.Waist = reader.GetInt32(8);
                    p.Inseam = reader.GetInt32(9);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                p = null;
            }
            finally
            {
                connection.Close();
            }
            // Will contain a Product if found and null if not

            return p;
        }

        public static DressShirt SelectDressShirt(string id)
        {
            DressShirt p = null;

            OleDbConnection connection = GetConnection();

            string select = "SELECT Product.ID, Product.Desc, Product.Price, "  // select stateent with inner join from dresshirt table 
                + "Product.Qty, Product.Type, Apparel.Material, Apparel.Color, Apparel.Manufacturer, "
                + "DressShirt.Neck, DressShirt.Sleeve FROM (Product INNER JOIN Apparel ON Product.ID = Apparel.ID) "
                + "INNER JOIN DressShirt ON Apparel.ID = DressShirt.ID WHERE Product.ID = '" + id + "';";

            OleDbCommand command = new OleDbCommand(select, connection);
            try
            {
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    // Instantiate and copy data from reader
                    p = new DressShirt();
                    p.ID = reader.GetString(0);
                    p.Desc = reader.GetString(1);
                    p.Price = reader.GetDouble(2);
                    p.Qty = reader.GetInt32(3);
                    p.Type = reader.GetString(4);
                    p.Material = reader.GetString(5);
                    p.Color = reader.GetString(6);
                    p.Manufacturer = reader.GetString(7);
                    p.Neck = reader.GetInt32(8);
                    p.Sleeve = reader.GetInt32(9);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                p = null;// if data was not copied properly 
            }
            finally
            {
                connection.Close();
            }
            // Will contain a Product if found and null if not

            return p;
        }

        public static TShirt SelectTShirt(string id)
        {
            TShirt p = null;

            OleDbConnection connection = GetConnection();

            string select = "SELECT Product.ID, Product.Desc, Product.Price, "        //slect statement with inner join from table thshirt 
                + "Product.Qty, Product.Type, Apparel.Material, Apparel.Color, Apparel.Manufacturer, "
                + "TShirt.SizeT FROM (Product INNER JOIN Apparel ON Product.ID = Apparel.ID)"
                + "INNER JOIN TShirt ON Apparel.ID = TShirt.ID WHERE Product.ID = '" + id + "';";

            OleDbCommand command = new OleDbCommand(select, connection);
            try
            {
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    // Instantiate and copy data from reader
                    p = new TShirt();
                    p.ID = reader.GetString(0);
                    p.Desc = reader.GetString(1);
                    p.Price = reader.GetDouble(2);
                    p.Qty = reader.GetInt32(3);
                    p.Type = reader.GetString(4);
                    p.Material = reader.GetString(5);
                    p.Color = reader.GetString(6);
                    p.Manufacturer = reader.GetString(7);
                    p.Size = reader.GetString(8);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                p = null; //if data was not copied properly
            }
            finally
            {
                connection.Close();
            }
            // Will contain a Product if found and null if not

            return p;
        }

        public static Book SelectBook(string id)
        {
            Book p = null;

            OleDbConnection connection = GetConnection();

            string select = "SELECT Product.ID, Product.Desc, Product.Price, "   //slect statement with inner join from table BOOK 
                + "Product.Qty, Product.Type, Media.ReleaseDate, Book.NumPages, Book.Author, "
                + "Book.Publisher FROM(Product INNER JOIN Media ON Product.ID = Media.ID) "
                + "INNER JOIN Book ON Media.ID = Book.ID WHERE Product.ID = '" + id + "';";

            OleDbCommand command = new OleDbCommand(select, connection);
            try
            {
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    // Instantiate and copy data from reader
                    p = new Book();
                    p.ID = reader.GetString(0);
                    p.Desc = reader.GetString(1);
                    p.Price = reader.GetDouble(2);
                    p.Qty = reader.GetInt32(3);
                    p.Type = reader.GetString(4);
                    p.ReleaseDate = reader.GetDateTime(5).ToShortDateString();
                    p.NumPages = reader.GetInt32(6);
                    p.Author = reader.GetString(7);
                    p.Publisher = reader.GetString(8);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                p = null;//if data was not copied properly
            }
            finally
            {
                connection.Close();
            }
            // Will contain a Product if found and null if not

            return p;
        }

        public static Software SelectSoftware(string id)
        {
            Software p = null;

            OleDbConnection connection = GetConnection();

            string select = "SELECT Product.ID, Product.Desc, Product.Price, "          //slect statement with inner join from table software 
                + "Product.Qty, Product.Type, Media.ReleaseDate, Disk.SizeDisk, Disk.NumDisks, "
                + "Disk.TypeDisk, Software.TypeSoft FROM ((Product INNER JOIN Media ON Product.ID = Media.ID)"
                + "INNER JOIN Disk ON Media.ID = Disk.ID) "
                + "INNER JOIN Software ON Disk.ID = Software.ID WHERE Product.ID = '" + id + "';";

            OleDbCommand command = new OleDbCommand(select, connection);
            try
            {
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    // Instantiate and copy data from reader
                    p = new Software();
                    p.ID = reader.GetString(0);
                    p.Desc = reader.GetString(1);
                    p.Price = reader.GetDouble(2);
                    p.Qty = reader.GetInt32(3);
                    p.Type = reader.GetString(4);
                    p.ReleaseDate = reader.GetDateTime(5).ToShortDateString();
                    p.Size = reader.GetInt32(6);
                    p.NumDisks = reader.GetInt32(7);
                    p.TypeDisk = reader.GetString(8);
                    p.TypeSoft = reader.GetString(9);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                p = null;//if data was not copied properly
            }
            finally
            {
                connection.Close();
            }

            // Will contain a Product if found and null if not


            return p;
        }

        public static Music SelectMusic(string id)
        {
            Music p = null;

            OleDbConnection connection = GetConnection();

            string select = "SELECT Product.ID, Product.Desc, Product.Price, "    //slect statement with inner join from table music
                + "Product.Qty, Product.Type, Media.ReleaseDate, Disk.SizeDisk, Disk.NumDisks, "
                + "Disk.TypeDisk, Entertainment.Hours, Entertainment.Minutes, Entertainment.Seconds, "
                + "Music.Genre, Music.Artist, Music.Label FROM"
                + "(((Product INNER JOIN Media ON Product.ID = Media.ID)"
                + "INNER JOIN Disk ON Media.ID = Disk.ID) "
                + "INNER JOIN Entertainment ON Disk.ID = Entertainment.ID) "
                + "INNER JOIN Music ON Entertainment.ID = Music.ID WHERE Product.ID = '" + id + "';";

            OleDbCommand command = new OleDbCommand(select, connection);
            try
            {
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    // Instantiate and copy data from reader
                    p = new Music(); 
                    p.ID = reader.GetString(0);
                    p.Desc = reader.GetString(1);
                    p.Price = reader.GetDouble(2);
                    p.Qty = reader.GetInt32(3);
                    p.Type = reader.GetString(4);
                    p.ReleaseDate = reader.GetDateTime(5).ToShortDateString();
                    p.Size = reader.GetInt32(6);
                    p.NumDisks = reader.GetInt32(7);
                    p.TypeDisk = reader.GetString(8);
                    string runTime = reader.GetInt32(9) + ":" + reader.GetInt32(10) + ":" + reader.GetInt32(11);
                    p.RunTime = runTime;
                    p.Genre = reader.GetString(12);
                    p.Artist = reader.GetString(13);
                    p.Label = reader.GetString(14);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                p = null;//if data was not copied properly
            }
            finally
            {
                connection.Close();
            }
            // Will contain a Product if found and null if not

            return p;
        }

        public static Movie SelectMovie(string id)
        {
            Movie p = null;

            OleDbConnection connection = GetConnection();

            string select = "SELECT Product.ID, Product.Desc, Product.Price, "       //slect statement with inner join from table movie
                + "Product.Qty, Product.Type, Media.ReleaseDate, Disk.SizeDisk, Disk.NumDisks, "
                + "Disk.TypeDisk, Entertainment.Hours, Entertainment.Minutes, Entertainment.Seconds, "
                + "Movie.Director, Movie.Producer FROM"
                + "(((Product INNER JOIN Media ON Product.ID = Media.ID) "
                + "INNER JOIN Disk ON Media.ID = Disk.ID) "
                + "INNER JOIN Entertainment ON Disk.ID = Entertainment.ID) "
                + "INNER JOIN Movie ON Entertainment.ID = Movie.ID WHERE Product.ID = '" + id + "';";

            OleDbCommand command = new OleDbCommand(select, connection);
            try
            {
                //open connection
                connection.Open();
                // Use command to execute a query with results in reader
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())// This reads and checks if a record need to be processed
                {
                    // Instantiate and copy data from reader
                    p = new Movie();
                    p.ID = reader.GetString(0);
                    p.Desc = reader.GetString(1);
                    p.Price = reader.GetDouble(2);
                    p.Qty = reader.GetInt32(3);
                    p.Type = reader.GetString(4);
                    p.ReleaseDate = reader.GetDateTime(5).ToShortDateString();
                    p.Size = reader.GetInt32(6);
                    p.NumDisks = reader.GetInt32(7);
                    p.TypeDisk = reader.GetString(8);
                    string runTime = reader.GetInt32(9) + ":" + reader.GetInt32(10) + ":" + reader.GetInt32(11);
                    p.RunTime = runTime;
                    p.Director = reader.GetString(12);
                    p.Producer = reader.GetString(13);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                p = null;//if data was not copied properly
            }
            finally
            {
                connection.Close();
            }

            return p;
        }

        // Insert into the DB
        public static bool InsertLineItem(int transID, string productID, int qty, double price)//insert into querty 
        {
            string str = "INSERT INTO LineItem (TransID, ProductID, Qty, Price) VALUES (" + transID + ", '" + productID + "', " + qty + ", " + price + ");";
            return ProductDB.ExeNonQuery(str);
        }

        // Insert into the DB
        public static bool InsertTrans(double subtotal, double tax, double total) //insert data into trans table 
        {
            string str = "INSERT INTO Trans (Subtotal, Tax, Total) VALUES (" + subtotal + ", " + tax + ", " + total + ");";
            return ProductDB.ExeNonQuery(str);
        }

        public static int SelectMaxTrans() //
        {
            OleDbConnection connection = GetConnection();
            string str = "SELECT MAX(ID) FROM Trans;";
            OleDbCommand command = new OleDbCommand(str, connection);
            int maxID = 0;
            try
            {
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();
                if (reader.Read())
                    maxID = reader.GetInt32(0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                connection.Close();
            }
            return maxID;
        }
        // Note that update is similar ti insert except for the update string

        public static bool UpdateProduct(string id, int quantity)
        {
            string str = "UPDATE Product SET Qty = " + quantity + " WHERE ID = '" + id + "';";
            return ProductDB.ExeNonQuery(str);
        }

        
        //select like statement 
        public static ArrayList SelectLikeDesc(string search)
        {
            ArrayList productArrayList = new ArrayList();
            OleDbConnection connection = GetConnection();

            string str = "SELECT ID, Desc, Price, Qty, Type FROM Product WHERE Desc LIKE '%" + search + "%';";

            OleDbCommand command = new OleDbCommand(str, connection);

            try
            {
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();
                

                while (reader.Read())
                {
                    Product productList = new Product();
                    productList.ID = reader.GetString(0);
                    productList.Desc = reader.GetString(1);
                    productList.Price = reader.GetDouble(2);
                    productList.Qty = reader.GetInt32(3);
                    productList.Type = reader.GetString(4);
                    productArrayList.Add(productList);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                productArrayList = null;
            }
            finally
            {
                connection.Close();
            }

            return productArrayList;
        }


    }
}